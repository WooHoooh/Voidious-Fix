# Alternate Assist

A Geometry Dash [Geode](https://geode-sdk.org) mod that helps you keep a steady spam-clicking rhythm.
Once your clicks-per-second (CPS) reach a threshold you choose, it takes over the *timing* of your
clicks and fires them evenly at a speed you choose. It stops as soon as you stop clicking, slow down,
or hold the button.

Targets **only** Windows x64 and Android ARM64 (arm64-v8a). Android 32-bit, iOS, macOS and Linux are
not built and the CMake project refuses to configure for them.

---

## Status: read this first

This source was written in an environment with **no Geode SDK, no MSVC / Android NDK, no network and no
Geometry Dash**. So:

| Item | State |
|---|---|
| Rhythm engine logic (`src/AssistEngine.hpp`) | **Tested** on a Linux host with g++ 13: 1481 checks pass (see "Tests that were run") |
| `mod.json` <-> code consistency (keys, types, defaults, custom setting types) | **Checked** by `tools/check_defaults.py` |
| Geode-facing files (`Hooks.cpp`, `Hud.cpp`, `SettingWidgets.cpp`, `Shared.cpp`) | Written against the Geode v5 docs; syntax-checked against stand-in headers only. **Never compiled against the real SDK** |
| Windows x64 build | **Not built. Not tested. Do not treat as supported yet.** |
| Android ARM64 build | **Not built. Not tested. Do not treat as supported yet.** |
| `.geode` packages | **Not produced.** The included GitHub Actions workflow builds them (below) |
| Behaviour inside Geometry Dash on either platform | **Untested** |

A platform becomes "supported" when its CI build is green **and** the test plan below has been run on
real hardware. Until then, expect to fix compile errors in the Geode-facing files (most likely hook
signatures or a custom-settings API detail - see "Where to look first").

---

## What it does

1. **Measures CPS.** Every press of the jump button is time-stamped. CPS is presses per second over the
   current click burst (a burst ends after a 0.6 s pause), so it reads correctly after just 3 clicks and
   decays to 0 when you stop.
2. **Activates at your threshold.** When CPS >= *Activation CPS* (and you have made at least 4 clicks in a
   row, the last one not after a pause) the assist turns on. The click that tipped it over becomes its
   first click.
3. **Holds a steady rhythm.** While active it presses and releases the button itself at
   `drive = pace + strength x (target - pace)` clicks per second, perfectly evenly spaced, where `pace` is
   your own smoothed CPS. Your own presses are swallowed meanwhile; they only keep the assist alive.
   * Strength 0 %: replays *your* average speed evenly (smoothing only).
   * Strength 100 %: locks to *Target CPS*.
4. **Stops by itself** (and resyncs the game's button to your finger) when you stop clicking
   (about 0.15-0.4 s), your CPS falls below 75 % of the threshold, you hold the button down for longer
   than *Hold Detection*, you press the other player's side, you change level state (restart / quit), or you
   switch the feature off.
5. **Disabled or below the threshold = vanilla.** Every click is forwarded to the game untouched, with no
   added latency (verified by test: the game sees an identical event stream).

Only the jump button (button 1) is touched. Platformer left/right, menus and the editor are never affected.

## Settings (Mods -> Alternate Assist -> Settings)

| Setting | Default | Range | Meaning |
|---|---|---|---|
| Enable Alternate Assist | on | | Master switch |
| Activation CPS | 8 | 3-25 | Assist starts at this click speed |
| Target CPS | 12 | 4-30 | Speed the assist aims for |
| Assistance Strength | 60 % | 0-100 % | 0 % = your own pace, 100 % = lock to Target CPS |
| Live CPS | | | Live counter + **TAP pad** to try it without a level |
| Assist Status | | | DISABLED / INACTIVE / ACTIVE (+ speed being produced) |
| Show HUD | on | | In-level overlay with CPS + status; pulses when the assist switches on |
| HUD Position | Top Left | 4 corners | |
| Hold Detection (ms) | 110 | 60-250 | Button held this long = you are holding, not spamming |
| Reset to Defaults | | | Writes every default back (reopen the page to see sliders move) |

Settings are saved by Geode between sessions. Defaults live in `src/Defaults.hpp` and must equal
`mod.json` (CI enforces this).

---

## Build

The mod is pinned to **Geode 5.11.2 / Geometry Dash 2.2081** (the newest stable release I could find on
10 Nov 2026 - check for a newer one). See "Retargeting" if your GD is newer.

Before building, edit `mod.json`: set `id` (`yourname.alternate-assist`) and `developer`.

### Option A - GitHub Actions (recommended; needs no local toolchain)

1. Create a GitHub repo and push this folder.
2. Open **Actions -> Build Alternate Assist -> Run workflow** (it also runs on every push).
3. When it finishes, download the artifacts:
   * `alternate-assist-windows-x64`  -> `.geode` for Windows
   * `alternate-assist-android-arm64` -> `.geode` for Android
   * The `engine-tests` job shows the logic test results.

The workflow uses `geode-sdk/build-geode-mod`, which installs the SDK version named in `mod.json`.

### Option B - local

Install the [Geode CLI](https://docs.geode-sdk.org/getting-started/geode-cli) and run `geode sdk install`.

**Windows x64:** Visual Studio 2022 (or Build Tools) with the *Desktop development with C++* workload, CMake, then
```
geode build
```

**Android ARM64** (from Windows, Linux or macOS; needs the Android NDK, `ANDROID_NDK_ROOT` set, and Ninja on Windows):
```
geode sdk install-binaries -p android64
geode build -p android64
```

The `.geode` file is written to the build folder. Check the
[Geode docs](https://docs.geode-sdk.org/getting-started/create-mod) for the current CLI details.

### Install

* **Windows:** copy the `.geode` into `<Geometry Dash folder>\geode\mods\`.
* **Android:** copy it to `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`
  (Geode launcher), then restart GD.

### Retargeting to another Geode / GD version

From the sources I found (1 Nov 2026), Geometry Dash 2.209x is supported by Geode v6, which was still an alpha.
To try it, change `"geode"` and `"gd"` in `mod.json`, follow the Geode v5 -> v6 migration notes, and rebuild.
**Not attempted here.**

---

## Test plan (run on BOTH platforms before calling either one supported)

| # | Test | Pass criteria |
|---|---|---|
| 1 | Install, launch GD, open Mods -> Alternate Assist -> Settings | All 10 controls (plus 4 section titles) appear in order; no Geode error in the log |
| 2 | Tap the **TAP** pad slowly (about 2-4 CPS) | Live CPS tracks your speed; status stays INACTIVE |
| 3 | Tap fast (above your Activation CPS) | Status turns ACTIVE within about 4 taps; stops about 0.2 s after you stop |
| 4 | Move Activation CPS up/down | Threshold moves accordingly (CPS accuracy: compare with an online CPS test) |
| 5 | Change settings, fully close GD, reopen | All values persisted |
| 6 | **Reset to Defaults**, reopen the page | Values equal the table above |
| 7 | Enter a level (practice mode), spam | HUD shows CPS; pulses and shows ASSIST on activation; clicks are even at the drive speed |
| 8 | Stop spamming / hold the button | Assist stops; a hold is passed through (up to Hold Detection of delay) |
| 9 | Disable the mod, play normally | Indistinguishable from vanilla |
| 10 | Die / restart / pause / quit mid-spam | No stuck button, no phantom click on the next attempt |
| 11 | 10+ minutes of play | No crash, no FPS drop, no growing memory |
| 12 | GD option *Click Between Steps*: test both on and off (2.208+) | Assist behaves the same; note any timing weirdness |

Collect Geode's log (`geode/logs`) for any failure.

## Where to look first if the build fails

1. `Hooks.cpp`: `handleButton`, `update`, `setupHasCompleted`, `resetLevel`, `onQuit` must match the
   2.2081 bindings exactly and exist for both `win` and `android64`.
2. `SettingWidgets.cpp`: custom setting API (`SettingV3`, `SettingNodeV3`, `checkJson`,
   `registerCustomSettingType`). Geode 5.10.1 fixed a custom-settings bug, so keep `geode` >= 5.10.1.
3. `Hud.cpp`: only core cocos2d classes; `CCDrawNode::drawDot` is the least common one.

## Known limitations

* **Hold latency.** While active, your presses are swallowed. If you switch from spamming to a deliberate
  hold, the game sees it after *Hold Detection* (default 110 ms); the assist's own last release can briefly
  precede it. Worst case measured in the logic tests: 62 ms of "up" before the hold took over.
* **Frame rate.** The assist injects on frame boundaries. Good rhythm needs FPS of at least about 2.5x the
  speed it produces (rhythm variation in tests: 4 % at 60 FPS, 1-2 % at 144-240 FPS).
* **Click timestamps** are taken when GD dispatches the input, so single-interval accuracy is one frame;
  averaged CPS is accurate (under 4 % error in tests).
* Designed for **one finger / key**. Two-finger alternate tapping works but usually keeps the assist off.
* In 2-player split-screen mode the assist yields when the other side is pressed.
* **Untested with GD 2.208's native Click Between Steps / Click On Steps**, or with other input mods
  (e.g. Click Between Frames, macro bots). Injected clicks go through `GJBaseGameLayer::handleButton` on frame
  boundaries.
* Only active in real levels (`PlayLayer`), not in the editor.
* **Fair play:** this changes your input. It is tagged `cheat` in `mod.json`. Don't use it where leaderboard,
  verification or tournament rules forbid assists.

## Tests that were run (host only)

```
g++ -std=c++20 -O2 -Wall -Wextra -Werror -I src tests/engine_test.cpp -o engine_test && ./engine_test
python3 tools/check_defaults.py
```

Results on Linux / g++ 13.3 (these say nothing about Windows or Android builds):

* CPS accuracy: 0.0 % error on steady trains 2-40 CPS (exact timestamps), at most 4.0 % with 60 FPS
  quantised timestamps, 3.7 % mean error on +-25 % jittery 10 CPS input.
* Activation: 13 rate/threshold cases correct; activates on the 4th click; a lone click after a pause never
  activates it.
* Pass-through: identical event streams when disabled or below threshold (452 and 648 events).
* Output rate vs strength at 60 / 144 / 240 FPS: within 3 % of `pace + strength x (target - pace)` (test bound 7 %).
* Rhythm consistency on jittery input: interval variation 0.145 -> 0.043 (60 FPS), 0.019 (144), 0.011 (240).
* Stops 121-133 ms after the last real click; releases the button; hands holds back.
* 300 randomised 20 s runs (mixed spam / holds / taps, 30-240 FPS, config changes mid-run) plus 200 two-finger
  runs: no double press/release, nothing stuck, longest assist-held button with no finger down 44.4 ms.
* Cost: 7.8 ns per frame while inactive, 36 ns while active.

## Layout

```
mod.json              Geode metadata + all settings (Geode 5.11.2, GD 2.2081, win + android only)
CMakeLists.txt        Geode v5 project, hard platform guard (Win64 / Android arm64-v8a only)
src/AssistEngine.hpp  Rhythm engine - pure C++, no Geode dependency
src/Hooks.cpp         GD input hooks, per-frame injection, level start/restart/quit
src/Hud.*             In-level overlay
src/SettingWidgets.cpp  Live CPS + TAP pad, status indicator, reset button (custom settings)
src/Shared.*          Clock, engines, settings bridge, injection helper
src/Defaults.hpp      Default values (must equal mod.json)
tests/engine_test.cpp Host-side tests
tools/check_defaults.py  mod.json <-> code consistency check
.github/workflows/build.yml  CI: tests + Windows x64 + Android ARM64 .geode
```
