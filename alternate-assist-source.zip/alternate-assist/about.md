# Alternate Assist

Keeps your spam-clicking at a **steady rhythm**.

Click faster than your **Activation CPS** and the assist takes over the *timing* of your clicks,
firing them evenly at your **Target CPS** until you stop, slow down, or hold the button.
Below the threshold, or with the mod disabled, every click reaches the game exactly as you made it.

## Settings

- **Activation CPS** - the click speed that switches the assist on.
- **Target CPS** - the speed it aims for.
- **Assistance Strength** - 0% evens out your own pace, 100% locks to the target.
- **Live CPS / Assist Status** - live readout with a **TAP pad**: try the counter and threshold without starting a level.
- **HUD** - a small in-level overlay with your CPS and the assist status. It pulses when the assist switches on.
- **Hold Detection** - how long you must hold the button before the assist hands it back to you.
- **Reset to Defaults**.

## Good to know

- Only the jump button is affected. The editor and platformer left/right are untouched.
- This changes your input, like any assist. Don't use it where leaderboard or verification rules forbid it.
- Works best at 60+ FPS (the faster the frame rate, the steadier the rhythm).
