# v1.0.0

- Initial release.
- CPS detection, threshold-activated click assist, assistance strength and target CPS.
- Settings page with live CPS counter + tap pad, status indicator and reset button.
- In-level HUD with an activation pulse.
