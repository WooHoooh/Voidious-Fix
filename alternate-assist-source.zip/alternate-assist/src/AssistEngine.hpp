#pragma once

// Alternate Assist - core rhythm engine.
//
// Pure C++20. It knows nothing about Geometry Dash or Geode, which is what makes it
// unit-testable on any machine (see tests/engine_test.cpp). The Geode layer feeds it the
// player's real button events plus one tick() per frame, and does whatever it says.
//
// Behaviour in one paragraph:
//   * Every real press of the jump button is time-stamped and the player's CPS is measured
//     over the current click burst (see cps()).
//   * While the assist is NOT active (feature off, or CPS below the activation threshold)
//     every real event is forwarded untouched: vanilla behaviour, no added latency.
//   * When CPS reaches the activation threshold the assist switches on. It adopts the press
//     that tipped it over as its first click and from then on drives the button itself at
//       drive = pace + strength * (target - pace)          (pace = the player's smoothed CPS)
//     clicks per second, evenly spaced. The player's own presses/releases are swallowed
//     while it is active; they only keep the assist alive and update `pace`.
//   * It switches off (and resyncs the game's button state to the player's finger) when the
//     player stops clicking, slows well below the threshold, holds the button down, switches
//     to the other player's side, or the feature is disabled.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace aa {

struct Config {
    bool   enabled       = true;
    double activationCps = 8.0;   // assist engages once the player clicks at least this fast
    double targetCps     = 12.0;  // rate the assist drives towards
    double strength      = 0.6;   // 0..1  (0 = replay the player's own pace evenly, 1 = lock to targetCps)
    double holdBreak     = 0.11;  // seconds a finger must stay down before the assist hands the button back
};

enum class Action : std::uint8_t { None, Press, Release };

struct PressResult {
    bool forward = true;              // pass the real press on to the game
    bool preRelease = false;          // send a synthetic release BEFORE forwarding (assist was holding the button)
    bool preReleaseIsPlayer1 = true;  // which side that synthetic release belongs to
    bool activated = false;           // the assist switched on with this press
};

struct ReleaseResult {
    bool forward = true;              // pass the real release on to the game
};

struct TickResult {
    Action action = Action::None;     // synthetic event to send to the game right now
    bool isPlayer1 = true;            // side to send it on
    bool deactivated = false;         // the assist switched off on this tick
};

struct ResetResult {
    Action action = Action::None;     // synthetic release to send, if the assist was holding the button
    bool isPlayer1 = true;
};

struct Snapshot {
    double cps = 0.0;                 // player's current CPS
    double driveCps = 0.0;            // rate the assist is currently producing (0 when inactive)
    bool enabled = false;
    bool active = false;
    std::uint32_t assisted = 0;       // total synthetic presses sent so far (monotonic)
};

class Engine {
public:
    static constexpr double kWindow     = 1.0;   // CPS look-back, seconds
    static constexpr double kBurstGap   = 0.6;   // a longer pause ends a click burst, seconds
    static constexpr int    kMinClicks  = 4;     // presses in the burst required before the assist may start
    static constexpr double kHysteresis = 0.75;  // stays active until CPS < activation * this
    static constexpr double kMaxCps     = 60.0;  // hard cap for any rate we report or produce

    void setConfig(Config const& c) {
        cfg_.enabled       = c.enabled;
        cfg_.activationCps = clampd(c.activationCps, 1.0, kMaxCps);
        cfg_.targetCps     = clampd(c.targetCps, 1.0, kMaxCps);
        cfg_.strength      = clampd(c.strength, 0.0, 1.0);
        cfg_.holdBreak     = clampd(c.holdBreak, 0.04, 0.5);
    }
    Config const& config() const { return cfg_; }

    // ---- real input -------------------------------------------------------------------

    PressResult onRealPress(double now, bool isPlayer1) {
        PressResult out;
        lastSeen_ = now;

        if (!active_ && count_ > 0 && histSide_ != isPlayer1) clearHistory();  // other side: start a fresh burst
        pushPress(now);
        histSide_ = isPlayer1;

        if (phys_ == 0) holdStart_ = now;
        ++phys_;
        lastRealPress_ = now;

        if (active_) {
            if (cfg_.enabled && isPlayer1 == side_) {
                updatePace();
                out.forward = false;              // the assist owns the button while it is active
                return out;
            }
            // Feature switched off, or the other player's side was pressed: hand control back.
            out.preRelease = assistHolding_;
            out.preReleaseIsPlayer1 = side_;
            active_ = false;
            assistHolding_ = false;
            clearHistory();
            pushPress(now);
            side_ = isPlayer1;
            gameDown_ = true;
            return out;                           // forward stays true
        }

        side_ = isPlayer1;
        gameDown_ = true;
        if (cfg_.enabled && shouldActivate()) {
            beginActive(now);
            out.activated = true;                 // this press is forwarded and becomes the assist's first click
        }
        return out;
    }

    ReleaseResult onRealRelease(double now) {
        ReleaseResult out;
        lastSeen_ = now;
        if (phys_ > 0) --phys_;
        if (active_) {
            out.forward = false;                  // the assist decides when the game sees a release
            return out;
        }
        gameDown_ = false;
        return out;
    }

    // ---- per-frame ----------------------------------------------------------------------

    TickResult tick(double now) {
        TickResult out;
        out.isPlayer1 = side_;
        lastSeen_ = now;
        if (!active_) return out;                 // cheap path: nothing to do while inactive

        const bool finger = phys_ > 0;
        const double rate = rawRate(burst());
        const double period = 1.0 / std::max(pace_, 1.0);
        const double idleTimeout = clampd(1.8 * period, 0.15, 0.40);

        const bool idle = !finger && (now - lastRealPress_) > idleTimeout;   // player stopped clicking
        const bool held = finger && (now - holdStart_) > cfg_.holdBreak;    // player is holding, not spamming
        const bool slow = rate < cfg_.activationCps * kHysteresis;          // fell below the configured conditions
        if (!cfg_.enabled || idle || held || slow) {
            out.action = leaveActive(finger);
            out.deactivated = true;
            return out;
        }

        if (assistHolding_) {
            // Don't cut a hold: if the finger has already been down for a good part of the hold-break
            // time it may be a real hold, so keep the button down and let the held-detection above hand
            // it over without a gap. Ordinary spam taps are shorter than this and never delay a release.
            const bool looksLikeHold = finger && (now - holdStart_) >= 0.5 * cfg_.holdBreak;
            if (now >= releaseAt_ && !looksLikeHold) {
                assistHolding_ = false;
                gameDown_ = false;
                out.action = Action::Release;
            }
            return out;
        }

        if (now >= nextTick_) {
            const double period2 = 1.0 / driveCps();
            nextTick_ += period2;
            if (nextTick_ < now) nextTick_ = now;  // fell behind (frame hitch): skip the backlog, never burst
            assistHolding_ = true;
            gameDown_ = true;
            ++assisted_;
            releaseAt_ = now + holdFor(period2);
            out.action = Action::Press;
        }
        return out;
    }

    // Level (re)start / quit: forget everything. Returns a release if the assist was holding the button.
    ResetResult reset() {
        ResetResult r;
        r.isPlayer1 = side_;
        if (active_ && assistHolding_) r.action = Action::Release;
        active_ = false;
        assistHolding_ = false;
        gameDown_ = false;
        phys_ = 0;
        pace_ = 0.0;
        lastRealPress_ = -1e9;
        holdStart_ = -1e9;
        nextTick_ = 0.0;
        releaseAt_ = 0.0;
        clearHistory();
        return r;
    }

    // ---- readouts -----------------------------------------------------------------------

    // Player's current CPS: presses per second over the current click burst, decaying to 0
    // once the player stops. A "burst" is the run of presses that are < kBurstGap apart and
    // fall inside the last kWindow seconds.
    double cps(double now) const {
        const double r = rawRate(burst());
        if (r <= 0.0) return 0.0;
        const double since = now - lastPressTime();
        if (since > kWindow) return 0.0;
        return since > 0.0 ? std::min(r, 1.0 / since) : r;
    }

    Snapshot snapshot(double now) const {
        Snapshot s;
        s.cps = cps(now);
        s.enabled = cfg_.enabled;
        s.active = active_ && (now - lastSeen_) < 0.5;   // stale if nobody has ticked us lately
        s.driveCps = s.active ? driveCps() : 0.0;
        s.assisted = assisted_;
        return s;
    }

    bool active() const { return active_; }
    bool isPlayer1() const { return side_; }
    bool gameButtonDown() const { return gameDown_; }
    bool fingerDown() const { return phys_ > 0; }
    std::uint32_t assisted() const { return assisted_; }

private:
    struct Burst {
        int m = 0;
        double first = 0.0;
        double last = 0.0;
        double lastGap = 1e9;
    };

    static double clampd(double v, double lo, double hi) {
        if (!std::isfinite(v)) return lo;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    static constexpr int kCap = 64;

    void pushPress(double t) {
        times_[head_] = t;
        head_ = (head_ + 1) % kCap;
        if (count_ < kCap) ++count_;
    }
    double newest(int k) const { return times_[(head_ - 1 - k + 2 * kCap) % kCap]; }   // k = 0 is the newest
    double lastPressTime() const { return count_ > 0 ? newest(0) : -1e9; }
    void clearHistory() { head_ = 0; count_ = 0; }

    Burst burst() const {
        Burst b;
        if (count_ == 0) return b;
        b.m = 1;
        b.last = b.first = newest(0);
        double prev = b.last;
        for (int k = 1; k < count_; ++k) {
            const double t = newest(k);
            const double gap = prev - t;
            if (gap > kBurstGap || b.last - t > kWindow) break;
            if (b.m == 1) b.lastGap = gap;
            ++b.m;
            b.first = t;
            prev = t;
        }
        return b;
    }

    static double rawRate(Burst const& b) {
        if (b.m < 2) return 0.0;
        const double span = b.last - b.first;
        if (span < 1e-4) return 0.0;
        return std::min((b.m - 1) / span, b.m >= 3 ? kMaxCps : 12.0);
    }

    bool shouldActivate() const {
        const Burst b = burst();
        if (b.m < kMinClicks) return false;
        if (rawRate(b) < cfg_.activationCps) return false;
        if (b.lastGap > 1.8 / cfg_.activationCps) return false;   // a lone click after a pause must not trigger it
        return true;
    }

    void updatePace() {
        const double r = rawRate(burst());
        if (r > 0.0) pace_ += 0.3 * (r - pace_);
    }

    double driveCps() const {
        const double p = std::max(pace_, 1.0);
        return clampd(p + cfg_.strength * (cfg_.targetCps - p), 2.0, kMaxCps);
    }

    static double holdFor(double period) { return clampd(0.4 * period, 0.012, 0.045); }

    void beginActive(double now) {
        active_ = true;
        assistHolding_ = true;       // the press that tipped us over is adopted as the first click
        gameDown_ = true;
        pace_ = rawRate(burst());
        const double period = 1.0 / driveCps();
        releaseAt_ = now + holdFor(period);
        nextTick_ = now + period;
    }

    // Leaves assist mode and returns whatever the game needs to see so that its button state
    // matches the player's finger from here on.
    Action leaveActive(bool fingerDown) {
        Action a = Action::None;
        if (assistHolding_) {
            if (!fingerDown) a = Action::Release;   // finger down: the held button now simply belongs to the player
        } else if (fingerDown) {
            a = Action::Press;                      // player is holding but the game saw the assist's release
        }
        active_ = false;
        assistHolding_ = false;
        gameDown_ = fingerDown;
        clearHistory();
        return a;
    }

    Config cfg_{};

    std::array<double, kCap> times_{};
    int head_ = 0;
    int count_ = 0;
    bool histSide_ = true;

    bool active_ = false;
    bool assistHolding_ = false;   // an assist-made press is currently down in the game
    bool gameDown_ = false;        // what the game believes the button state is
    bool side_ = true;             // isPlayer1 of the clicks being assisted

    int phys_ = 0;                 // fingers / keys physically down right now
    double holdStart_ = -1e9;
    double lastRealPress_ = -1e9;
    double lastSeen_ = -1e9;

    double pace_ = 0.0;            // smoothed player CPS while active
    double nextTick_ = 0.0;
    double releaseAt_ = 0.0;
    std::uint32_t assisted_ = 0;
};

}  // namespace aa
