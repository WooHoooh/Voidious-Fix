#pragma once

// Default values for every Alternate Assist setting.
//
// These MUST match the "default" fields in mod.json. The "Reset to Defaults" button writes
// these values, and tools/check_defaults.py (run in CI) fails if the two ever drift apart.

#include <cstdint>

namespace aa::defaults {

inline constexpr bool         enabled       = true;
inline constexpr double       activationCps = 8.0;
inline constexpr double       targetCps     = 12.0;
inline constexpr std::int64_t strength      = 60;      // percent
inline constexpr std::int64_t holdBreakMs   = 110;
inline constexpr bool         showHud       = true;
inline constexpr const char*  hudPosition   = "Top Left";

}  // namespace aa::defaults
