// The only place that touches Geometry Dash's input path.
//
//   GJBaseGameLayer::handleButton   every real press/release of the jump button passes through here;
//                                   the engine decides whether it is forwarded or swallowed.
//   GJBaseGameLayer::update         once per frame the engine may ask for a synthetic press/release.
//   PlayLayer::setupHasCompleted    level start: reset the engine, attach the HUD.
//   PlayLayer::resetLevel           death / restart: reset the engine, release an assist-held button.
//   PlayLayer::onQuit               leaving the level: reset the engine.
//
// Everything outside a live PlayLayer (menus, the editor, the settings page) is passed straight through.

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include "AssistEngine.hpp"
#include "Hud.hpp"
#include "Shared.hpp"

using namespace geode::prelude;

class $modify(AssistBaseLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        // Not the jump button, one of our own synthetic events, or not a live level: vanilla path.
        if (button != 1 || aa::g_injecting || !aa::isPlayLayer(this)) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        const double t = aa::now();
        aa::refreshConfig(t);
        auto& engine = aa::gameEngine();

        if (down) {
            const auto r = engine.onRealPress(t, isPlayer1);
            if (r.preRelease) aa::injectButton(this, false, r.preReleaseIsPlayer1);
            if (r.forward) GJBaseGameLayer::handleButton(true, button, isPlayer1);
        } else {
            const auto r = engine.onRealRelease(t);
            if (r.forward) GJBaseGameLayer::handleButton(false, button, isPlayer1);
        }
    }

    void update(float dt) {
        if (aa::isPlayLayer(this)) {
            const double t = aa::now();
            aa::refreshConfig(t);
            const auto out = aa::gameEngine().tick(t);
            if (out.action != aa::Action::None) {
                aa::injectButton(this, out.action == aa::Action::Press, out.isPlayer1);
            }
        }
        GJBaseGameLayer::update(dt);
    }
};

class $modify(AssistPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        aa::gameEngine().reset();

        CCNode* parent = UILayer::get();
        if (!parent) parent = this;
        aa::attachHud(parent);
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        const auto r = aa::gameEngine().reset();
        if (r.action == aa::Action::Release) aa::injectButton(this, false, r.isPlayer1);
    }

    void onQuit() {
        aa::gameEngine().reset();
        PlayLayer::onQuit();
    }
};
