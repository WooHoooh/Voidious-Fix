#include "Hud.hpp"

#include <cstdint>
#include <cstdio>
#include <string>

#include "Shared.hpp"

using namespace geode::prelude;

namespace {

constexpr float kPanelW = 124.f;
constexpr float kPanelH = 38.f;
constexpr float kMargin = 8.f;
constexpr float kHudScale = 0.9f;

enum class HudState : int { Disabled = 0, Inactive = 1, Active = 2 };

// Small translucent panel: status dot + accent bar on the left, "CPS 12.3" over the status line.
// It is polled ten times a second and only touches a label when its text actually changes.
class AssistHud : public CCNode {
protected:
    CCLayerColor* m_bg = nullptr;
    CCLayerColor* m_accent = nullptr;
    CCDrawNode* m_dot = nullptr;
    CCLabelBMFont* m_cps = nullptr;
    CCLabelBMFont* m_state = nullptr;

    int m_lastCpsTenths = -1;
    int m_lastDriveTenths = -1;
    int m_lastState = -1;
    std::uint32_t m_lastAssisted = 0;
    std::string m_lastPos;
    bool m_lastShow = true;

    bool init() {
        if (!CCNode::init()) return false;

        this->setContentSize({kPanelW, kPanelH});
        this->setAnchorPoint({0.f, 0.f});
        this->setScale(kHudScale);

        m_bg = CCLayerColor::create(ccc4(0, 0, 0, 120), kPanelW, kPanelH);
        this->addChild(m_bg, 0);

        m_accent = CCLayerColor::create(ccc4(140, 140, 140, 255), 3.f, kPanelH);
        this->addChild(m_accent, 1);

        m_dot = CCDrawNode::create();
        m_dot->setPosition({15.f, kPanelH * 0.5f});
        this->addChild(m_dot, 2);

        m_cps = CCLabelBMFont::create("CPS 0.0", "bigFont.fnt");
        m_cps->setAnchorPoint({0.f, 0.5f});
        m_cps->setScale(0.42f);
        m_cps->setPosition({26.f, kPanelH * 0.70f});
        this->addChild(m_cps, 2);

        m_state = CCLabelBMFont::create("INACTIVE", "bigFont.fnt");
        m_state->setAnchorPoint({0.f, 0.5f});
        m_state->setScale(0.32f);
        m_state->setPosition({26.f, kPanelH * 0.30f});
        this->addChild(m_state, 2);

        this->applyState(HudState::Inactive, 0.0);
        this->schedule(schedule_selector(AssistHud::tick), 0.1f);
        this->tick(0.f);
        return true;
    }

    void setDot(ccColor3B c) {
        m_dot->clear();
        m_dot->drawDot({0.f, 0.f}, 4.5f, ccc4f(c.r / 255.f, c.g / 255.f, c.b / 255.f, 1.f));
    }

    void place(std::string const& pos) {
        const auto win = CCDirector::sharedDirector()->getWinSize();
        const float w = kPanelW * kHudScale;
        const float h = kPanelH * kHudScale;
        const bool right = pos.find("Right") != std::string::npos;
        const bool bottom = pos.find("Bottom") != std::string::npos;
        this->setPosition({right ? win.width - kMargin - w : kMargin, bottom ? kMargin : win.height - kMargin - h});
    }

    void pulse() {
        this->stopAllActions();
        this->setScale(kHudScale);
        this->runAction(CCSequence::create(CCScaleTo::create(0.07f, kHudScale * 1.14f),
                                           CCScaleTo::create(0.16f, kHudScale), nullptr));
    }

    void applyState(HudState state, double drive) {
        char buf[32];
        ccColor3B color;
        switch (state) {
            case HudState::Active:
                std::snprintf(buf, sizeof buf, "ASSIST %.1f", drive);
                color = ccc3(90, 255, 120);
                break;
            case HudState::Inactive:
                std::snprintf(buf, sizeof buf, "INACTIVE");
                color = ccc3(150, 150, 150);
                break;
            default:
                std::snprintf(buf, sizeof buf, "DISABLED");
                color = ccc3(100, 100, 100);
                break;
        }
        m_state->setString(buf);
        m_state->setColor(color);
        m_accent->setColor(color);
        this->setDot(color);
    }

    void tick(float) {
        const double t = aa::now();
        aa::refreshConfig(t);

        auto* mod = Mod::get();
        const bool show = mod->getSettingValue<bool>("show-hud");
        if (show != m_lastShow) {
            m_lastShow = show;
            this->setVisible(show);
        }
        if (!show) return;

        const std::string pos = mod->getSettingValue<std::string>("hud-position");
        if (pos != m_lastPos) {
            m_lastPos = pos;
            this->place(pos);
        }

        const auto snap = aa::gameEngine().snapshot(t);

        const int cpsTenths = static_cast<int>(snap.cps * 10.0 + 0.5);
        if (cpsTenths != m_lastCpsTenths) {
            m_lastCpsTenths = cpsTenths;
            char buf[24];
            std::snprintf(buf, sizeof buf, "CPS %.1f", cpsTenths / 10.0);
            m_cps->setString(buf);
        }

        const HudState state = !snap.enabled ? HudState::Disabled
                               : snap.active ? HudState::Active
                                             : HudState::Inactive;
        const int driveTenths = static_cast<int>(snap.driveCps * 10.0 + 0.5);
        if (static_cast<int>(state) != m_lastState || (state == HudState::Active && driveTenths != m_lastDriveTenths)) {
            const bool activated = state == HudState::Active && m_lastState != static_cast<int>(HudState::Active);
            m_lastState = static_cast<int>(state);
            m_lastDriveTenths = driveTenths;
            this->applyState(state, driveTenths / 10.0);
            if (activated) this->pulse();  // visual cue: the assist just switched on
        }

        if (snap.assisted != m_lastAssisted) {
            m_lastAssisted = snap.assisted;
            m_dot->stopAllActions();
            m_dot->setScale(1.6f);
            m_dot->runAction(CCScaleTo::create(0.08f, 1.f));  // blink on every assisted click
        }
    }

public:
    static AssistHud* create() {
        auto ret = new AssistHud();
        if (ret->init()) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

}  // namespace

namespace aa {

void attachHud(CCNode* parent) {
    if (!parent) return;
    if (auto* hud = AssistHud::create()) parent->addChild(hud, 1000);
}

}  // namespace aa
