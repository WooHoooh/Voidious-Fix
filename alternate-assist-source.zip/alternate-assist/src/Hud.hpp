#pragma once

#include <Geode/Geode.hpp>

namespace aa {

// Adds the small in-level overlay (live CPS + assist status) to `parent`.
void attachHud(cocos2d::CCNode* parent);

}  // namespace aa
