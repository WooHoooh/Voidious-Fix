// Three custom setting types that live inside the Alternate Assist section of Geode's mod settings:
//
//   custom:cps-readout     "Live CPS"        a live CPS number plus a TAP pad. Tap it quickly to try the
//                                            CPS counter and the activation threshold without starting a level.
//                                            While a level is running it shows the in-game value instead.
//   custom:assist-status   "Assist Status"   coloured dot + DISABLED / INACTIVE / ACTIVE (with the drive CPS).
//   custom:reset-button    "Reset to Defaults"
//
// They store no data of their own (load/save/reset are no-ops), so they never appear in the save file.
// Structure follows https://docs.geode-sdk.org/mods/settings (custom settings, "button" example).

#include <Geode/Geode.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/binding/FLAlertLayer.hpp>
#include <Geode/loader/SettingV3.hpp>

#include <cstdint>
#include <cstdio>

#include "Shared.hpp"

using namespace geode::prelude;

namespace {

enum class Kind { LiveCps, Status, Reset };

class AssistWidgetSetting : public SettingV3 {
public:
    Kind m_kind = Kind::LiveCps;

    static Result<std::shared_ptr<SettingV3>> parseAs(Kind kind, std::string const& key, std::string const& modID,
                                                      matjson::Value const& json) {
        auto res = std::make_shared<AssistWidgetSetting>();
        res->m_kind = kind;
        auto root = checkJson(json, "AssistWidgetSetting");
        res->init(key, modID, root);
        res->parseNameAndDescription(root);
        res->parseEnableIf(root);
        root.checkUnknownKeys();
        return root.ok(std::static_pointer_cast<SettingV3>(res));
    }
    static Result<std::shared_ptr<SettingV3>> parseLive(std::string const& key, std::string const& modID,
                                                        matjson::Value const& json) {
        return parseAs(Kind::LiveCps, key, modID, json);
    }
    static Result<std::shared_ptr<SettingV3>> parseStatus(std::string const& key, std::string const& modID,
                                                          matjson::Value const& json) {
        return parseAs(Kind::Status, key, modID, json);
    }
    static Result<std::shared_ptr<SettingV3>> parseReset(std::string const& key, std::string const& modID,
                                                         matjson::Value const& json) {
        return parseAs(Kind::Reset, key, modID, json);
    }

    bool load(matjson::Value const&) override { return true; }
    bool save(matjson::Value&) const override { return true; }
    bool isDefaultValue() const override { return true; }
    void reset() override {}

    SettingNodeV3* createNode(float width) override;
};

// Which engine should the readouts show? The tap pad if it was used in the last few seconds,
// otherwise the one that drives the real game.
aa::Snapshot currentSnapshot(double t) {
    if (t - aa::padLastTap() < 3.0) return aa::padEngine().snapshot(t);
    return aa::gameEngine().snapshot(t);
}

class AssistWidgetNode : public SettingNodeV3 {
protected:
    Kind m_kind = Kind::LiveCps;
    CCLabelBMFont* m_value = nullptr;
    CCLabelBMFont* m_state = nullptr;
    CCDrawNode* m_dot = nullptr;
    ButtonSprite* m_buttonSprite = nullptr;
    CCMenuItemSpriteExtra* m_button = nullptr;

    int m_lastTenths = -1;
    int m_lastState = -1;
    int m_lastDriveTenths = -1;
    std::uint32_t m_lastAssisted = 0;

    bool init(std::shared_ptr<AssistWidgetSetting> setting, float width) {
        if (!SettingNodeV3::init(setting, width)) return false;
        m_kind = setting->m_kind;

        auto* menu = this->getButtonMenu();
        switch (m_kind) {
            case Kind::LiveCps: {
                menu->setContentWidth(150.f);
                m_value = CCLabelBMFont::create("0.0", "bigFont.fnt");
                m_value->setScale(0.5f);
                menu->addChildAtPosition(m_value, Anchor::Left, {30.f, 0.f});

                m_buttonSprite = ButtonSprite::create("TAP", "goldFont.fnt", "GJ_button_01.png", .8f);
                m_buttonSprite->setScale(.55f);
                m_button = CCMenuItemSpriteExtra::create(m_buttonSprite, this, menu_selector(AssistWidgetNode::onTap));
                menu->addChildAtPosition(m_button, Anchor::Right, {-32.f, 0.f});
                break;
            }
            case Kind::Status: {
                menu->setContentWidth(120.f);
                m_dot = CCDrawNode::create();
                menu->addChildAtPosition(m_dot, Anchor::Left, {8.f, 0.f});
                m_state = CCLabelBMFont::create("INACTIVE", "bigFont.fnt");
                m_state->setScale(0.38f);
                m_state->setAnchorPoint({0.f, 0.5f});
                menu->addChildAtPosition(m_state, Anchor::Left, {20.f, 0.f});
                break;
            }
            case Kind::Reset: {
                menu->setContentWidth(80.f);
                m_buttonSprite = ButtonSprite::create("Reset", "goldFont.fnt", "GJ_button_01.png", .8f);
                m_buttonSprite->setScale(.55f);
                m_button = CCMenuItemSpriteExtra::create(m_buttonSprite, this, menu_selector(AssistWidgetNode::onReset));
                menu->addChildAtPosition(m_button, Anchor::Center);
                break;
            }
        }
        menu->updateLayout();
        this->updateState(nullptr);

        if (m_kind != Kind::Reset) {
            this->schedule(schedule_selector(AssistWidgetNode::refresh), 0.1f);
        }
        if (m_kind == Kind::LiveCps) {
            // drive the tap-pad engine every frame while this page is open (cost: a few ns)
            this->schedule(schedule_selector(AssistWidgetNode::padTick));
        }
        return true;
    }

    void setDot(ccColor3B c) {
        if (!m_dot) return;
        m_dot->clear();
        m_dot->drawDot({0.f, 0.f}, 5.f, ccc4f(c.r / 255.f, c.g / 255.f, c.b / 255.f, 1.f));
    }

    void padTick(float) {
        const double t = aa::now();
        aa::refreshConfig(t);
        (void)aa::padEngine().tick(t);
    }

    void refresh(float) {
        const double t = aa::now();
        const auto snap = currentSnapshot(t);

        if (m_kind == Kind::LiveCps && m_value) {
            const int tenths = static_cast<int>(snap.cps * 10.0 + 0.5);
            if (tenths != m_lastTenths) {
                m_lastTenths = tenths;
                char buf[24];
                std::snprintf(buf, sizeof buf, "%.1f CPS", tenths / 10.0);
                m_value->setString(buf);
                m_value->setColor(snap.active ? ccc3(90, 255, 120) : ccc3(255, 255, 255));
            }
        } else if (m_kind == Kind::Status && m_state) {
            const int state = !snap.enabled ? 0 : (snap.active ? 2 : 1);
            const int driveTenths = static_cast<int>(snap.driveCps * 10.0 + 0.5);
            if (state != m_lastState || (state == 2 && driveTenths != m_lastDriveTenths)) {
                m_lastState = state;
                m_lastDriveTenths = driveTenths;
                char buf[32];
                ccColor3B color;
                if (state == 2) {
                    std::snprintf(buf, sizeof buf, "ACTIVE %.1f", driveTenths / 10.0);
                    color = ccc3(90, 255, 120);
                } else if (state == 1) {
                    std::snprintf(buf, sizeof buf, "INACTIVE");
                    color = ccc3(200, 200, 200);
                } else {
                    std::snprintf(buf, sizeof buf, "DISABLED");
                    color = ccc3(110, 110, 110);
                }
                m_state->setString(buf);
                m_state->setColor(color);
                this->setDot(color);
            }
            if (snap.assisted != m_lastAssisted && m_dot) {
                m_lastAssisted = snap.assisted;
                m_dot->stopAllActions();
                m_dot->setScale(1.5f);
                m_dot->runAction(CCScaleTo::create(0.08f, 1.f));
            }
        }
    }

    void onTap(CCObject*) {
        const double t = aa::now();
        aa::refreshConfig(t, true);
        aa::padLastTap() = t;
        auto& pad = aa::padEngine();
        (void)pad.onRealPress(t, true);
        (void)pad.onRealRelease(t);
        this->refresh(0.f);
    }

    void onReset(CCObject*) {
        aa::resetSettingsToDefaults();
        FLAlertLayer::create("Alternate Assist",
                             "All Alternate Assist settings were reset to their defaults.\n"
                             "Close and reopen this page to see the new slider positions.",
                             "OK")
            ->show();
    }

    void updateState(CCNode* invoker) override {
        SettingNodeV3::updateState(invoker);
        if (m_button) m_button->setEnabled(this->getSetting()->shouldEnable());
    }

    // These widgets never hold a value, so there is nothing to commit or reset.
    void onCommit() override {}
    void onResetToDefault() override {}

public:
    bool hasUncommittedChanges() const override { return false; }
    bool hasNonDefaultValue() const override { return false; }

    static AssistWidgetNode* create(std::shared_ptr<AssistWidgetSetting> setting, float width) {
        auto ret = new AssistWidgetNode();
        if (ret->init(setting, width)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

SettingNodeV3* AssistWidgetSetting::createNode(float width) {
    return AssistWidgetNode::create(std::static_pointer_cast<AssistWidgetSetting>(shared_from_this()), width);
}

}  // namespace

$on_mod(Loaded) {
    (void)Mod::get()->registerCustomSettingType("cps-readout", &AssistWidgetSetting::parseLive);
    (void)Mod::get()->registerCustomSettingType("assist-status", &AssistWidgetSetting::parseStatus);
    (void)Mod::get()->registerCustomSettingType("reset-button", &AssistWidgetSetting::parseReset);
}
