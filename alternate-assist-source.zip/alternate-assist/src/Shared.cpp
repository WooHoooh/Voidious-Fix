#include "Shared.hpp"

#include <chrono>
#include <string>

#include "Defaults.hpp"

using namespace geode::prelude;

namespace aa {

bool g_injecting = false;

namespace {

struct InjectGuard {
    InjectGuard() { g_injecting = true; }
    ~InjectGuard() { g_injecting = false; }
    InjectGuard(InjectGuard const&) = delete;
    InjectGuard& operator=(InjectGuard const&) = delete;
};

}  // namespace

double now() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

Engine& gameEngine() {
    static Engine engine;
    return engine;
}

Engine& padEngine() {
    static Engine engine;
    return engine;
}

double& padLastTap() {
    static double t = -1e9;
    return t;
}

Config readConfig() {
    auto* mod = Mod::get();
    Config c;
    c.enabled       = mod->getSettingValue<bool>("enabled");
    c.activationCps = mod->getSettingValue<double>("activation-cps");
    c.targetCps     = mod->getSettingValue<double>("target-cps");
    c.strength      = static_cast<double>(mod->getSettingValue<int64_t>("strength")) / 100.0;
    c.holdBreak     = static_cast<double>(mod->getSettingValue<int64_t>("hold-break-ms")) / 1000.0;
    return c;
}

void refreshConfig(double t, bool force) {
    static double last = -1e9;
    if (!force && t - last < 0.1) return;
    last = t;
    const Config c = readConfig();
    gameEngine().setConfig(c);
    padEngine().setConfig(c);
}

void resetSettingsToDefaults() {
    auto* mod = Mod::get();
    (void)mod->setSettingValue<bool>("enabled", defaults::enabled);
    (void)mod->setSettingValue<double>("activation-cps", defaults::activationCps);
    (void)mod->setSettingValue<double>("target-cps", defaults::targetCps);
    (void)mod->setSettingValue<int64_t>("strength", defaults::strength);
    (void)mod->setSettingValue<int64_t>("hold-break-ms", defaults::holdBreakMs);
    (void)mod->setSettingValue<bool>("show-hud", defaults::showHud);
    (void)mod->setSettingValue<std::string>("hud-position", std::string(defaults::hudPosition));
    refreshConfig(now(), true);
}

bool isPlayLayer(GJBaseGameLayer* layer) {
    auto* play = PlayLayer::get();
    return play != nullptr && static_cast<GJBaseGameLayer*>(play) == layer;
}

void injectButton(GJBaseGameLayer* layer, bool down, bool isPlayer1) {
    if (!layer) return;
    InjectGuard guard;
    layer->handleButton(down, 1, isPlayer1);
}

}  // namespace aa
