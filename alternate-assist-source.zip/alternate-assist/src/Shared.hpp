#pragma once

#include <Geode/Geode.hpp>

#include "AssistEngine.hpp"

namespace aa {

// Monotonic clock in seconds (std::chrono::steady_clock - identical on Windows and Android).
double now();

// The engine that drives the real game, and a second one used by the "tap pad" in the settings
// page so CPS / activation can be tried out without starting a level.
Engine& gameEngine();
Engine& padEngine();
double& padLastTap();

// Settings -> engine config. refreshConfig() re-reads the Geode settings at most every 100 ms
// (or immediately with force) and pushes them into both engines.
Config readConfig();
void refreshConfig(double t, bool force = false);

// Writes every Alternate Assist setting back to its default (values live in Defaults.hpp).
void resetSettingsToDefaults();

// True only for the live PlayLayer (not the editor, menus, etc.).
bool isPlayLayer(GJBaseGameLayer* layer);

// Sends a synthetic jump-button event to the game. While it runs, our own handleButton hook
// lets the event straight through (g_injecting) so it is never mistaken for a real click.
extern bool g_injecting;
void injectButton(GJBaseGameLayer* layer, bool down, bool isPlayer1);

}  // namespace aa
