#include <Geode/Geode.hpp>

using namespace geode::prelude;

// All behaviour lives in Hooks.cpp (input), Hud.cpp (in-level overlay) and SettingWidgets.cpp
// (settings page widgets). This file only announces that the mod is up.
$on_mod(Loaded) {
    log::info("Alternate Assist loaded");
}
