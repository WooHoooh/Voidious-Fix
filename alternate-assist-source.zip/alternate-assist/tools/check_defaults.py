#!/usr/bin/env python3
"""Static consistency checks that need no Geode SDK, compiler or game.

  1. mod.json is valid JSON and only declares the two supported platforms (win, android).
  2. Every default in src/Defaults.hpp matches the "default" in mod.json (the Reset button uses
     Defaults.hpp, a fresh install uses mod.json - they must never drift apart).
  3. Defaults are inside their min/max range; string defaults are in their one-of list.
  4. Every setting key read or written in src/*.cpp exists in mod.json, with the matching type.
  5. Every "custom:<name>" type in mod.json is registered with registerCustomSettingType("<name>", ...).
  6. every enable-if refers to an existing bool setting.

Exit status 0 = all good.
"""
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
errors = []


def fail(msg):
    errors.append(msg)


mod = json.loads((ROOT / "mod.json").read_text())
settings = mod["settings"]

# 1. platforms ------------------------------------------------------------------------------
gd = mod.get("gd")
if not isinstance(gd, dict) or set(gd) != {"win", "android"}:
    fail(f'mod.json "gd" must be an object with exactly the keys win and android, got {gd!r}')

# 2/3. defaults -----------------------------------------------------------------------------
header = (ROOT / "src" / "Defaults.hpp").read_text()
consts = {}
for m in re.finditer(r"inline\s+constexpr\s+[\w:\s\*]+?\s+(\w+)\s*=\s*([^;]+);", header):
    name, raw = m.group(1), m.group(2).strip()
    if raw in ("true", "false"):
        consts[name] = raw == "true"
    elif raw.startswith('"'):
        consts[name] = raw.strip('"')
    else:
        consts[name] = float(raw)

pairs = {
    "enabled": "enabled",
    "activationCps": "activation-cps",
    "targetCps": "target-cps",
    "strength": "strength",
    "holdBreakMs": "hold-break-ms",
    "showHud": "show-hud",
    "hudPosition": "hud-position",
}
for cname, key in pairs.items():
    if cname not in consts:
        fail(f"Defaults.hpp has no constant '{cname}'")
        continue
    if key not in settings:
        fail(f"mod.json has no setting '{key}'")
        continue
    if "default" not in settings[key]:
        fail(f"mod.json setting '{key}' has no default")
        continue
    if consts[cname] != settings[key]["default"]:
        fail(f"default mismatch for '{key}': Defaults.hpp={consts[cname]!r} mod.json={settings[key]['default']!r}")
extra = set(consts) - set(pairs)
if extra:
    fail(f"Defaults.hpp constants not covered by this check: {sorted(extra)}")

for key, s in settings.items():
    t = s.get("type", "")
    if t not in ("title",) and not t.startswith("custom:") and "default" not in s:
        fail(f"setting '{key}' has no default")
    if t in ("int", "float") and "default" in s:
        if "min" in s and s["default"] < s["min"]:
            fail(f"setting '{key}': default below min")
        if "max" in s and s["default"] > s["max"]:
            fail(f"setting '{key}': default above max")
    if "one-of" in s and s.get("default") not in s["one-of"]:
        fail(f"setting '{key}': default not in one-of")

# 4. keys used by the code --------------------------------------------------------------------
cpp_type = {"bool": "bool", "double": "float", "int64_t": "int", "std::string": "string"}
used = []
for path in sorted((ROOT / "src").glob("*.[ch]pp")):
    text = path.read_text()
    for m in re.finditer(r'(?:get|set)SettingValue<\s*([\w:]+)\s*>\(\s*"([^"]+)"', text):
        used.append((path.name, m.group(1), m.group(2)))
if not used:
    fail("found no get/setSettingValue calls - check script is out of date")
for fname, ctype, key in used:
    if key not in settings:
        fail(f"{fname}: setting '{key}' is not declared in mod.json")
    elif cpp_type.get(ctype) != settings[key]["type"]:
        fail(f"{fname}: setting '{key}' is read as {ctype} but mod.json declares type '{settings[key]['type']}'")
# every real (non-title, non-custom) setting should be used by the code
used_keys = {k for _, _, k in used}
for key, s in settings.items():
    t = s["type"]
    if t != "title" and not t.startswith("custom:") and key not in used_keys:
        fail(f"setting '{key}' is declared in mod.json but never read by the code")

# 5. custom types ------------------------------------------------------------------------------
registered = set()
for path in (ROOT / "src").glob("*.cpp"):
    registered |= set(re.findall(r'registerCustomSettingType\(\s*"([^"]+)"', path.read_text()))
declared = {s["type"].split(":", 1)[1] for s in settings.values() if s["type"].startswith("custom:")}
for name in sorted(declared - registered):
    fail(f"custom setting type '{name}' is declared in mod.json but never registered")
for name in sorted(registered - declared):
    fail(f"custom setting type '{name}' is registered but not used in mod.json")

# 6. enable-if ---------------------------------------------------------------------------------
for key, s in settings.items():
    dep = s.get("enable-if")
    if dep is not None and settings.get(dep, {}).get("type") != "bool":
        fail(f"setting '{key}': enable-if '{dep}' is not a bool setting in mod.json")

if errors:
    print("check_defaults.py: FAILED")
    for e in errors:
        print("  -", e)
    sys.exit(1)

print(f"check_defaults.py: OK ({len(settings)} settings, {len(used)} code references, "
      f"{len(declared)} custom types, platforms: {', '.join(sorted(gd))})")
